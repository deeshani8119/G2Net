Transient CW searches
============================

F-statistic based searches for transient CW signals.
See `arXiv:1104.1704 [gr-qc]`_.

.. _arXiv:1104.1704 [gr-qc]: https://arxiv.org/abs/1104.1704
