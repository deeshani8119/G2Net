This page contains basic information about the PyFstat package,
including installation instructions,
a contributing guide
and the proper way to cite the package and the underlying scientific literature.
This is equivalent to the package's
`README.md file <https://github.com/PyFstat/PyFstat/blob/master/README.md>`_
.

See :doc:`here <pyfstat>` for the full API documentation.


.. mdinclude:: ../../README.md 
