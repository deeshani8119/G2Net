Glitch robust CW searches
============================

Extension of standard CW search methods to increase its robustness
against astrophysical glitches. See `arXiv:1805.03314 [gr-qc]`_.

.. _arXiv:1805.03314 [gr-qc]: https://arxiv.org/abs/1805.03314
