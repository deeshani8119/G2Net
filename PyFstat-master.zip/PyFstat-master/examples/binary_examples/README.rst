Binary-modulated CW searches
============================

Application of MCMC F-statistic algorithms to the search
for continuous gravitational wave sources in binary systems.
