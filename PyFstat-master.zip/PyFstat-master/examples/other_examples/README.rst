Other examples
==============

Summary of use cases of the different tools provided by PyFstat.
