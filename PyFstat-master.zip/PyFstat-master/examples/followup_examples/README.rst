Multi-stage MCMC follow up
==========================

Application of MCMC F-statistic algorithms to the follow up of a CW signal candidate.
