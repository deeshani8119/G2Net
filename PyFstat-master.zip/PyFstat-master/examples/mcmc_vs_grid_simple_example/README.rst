Comparison between MCMC and Grid searches
=========================================

Run an MCMC and a Grid search on the same data to perform a 
consistency check.
