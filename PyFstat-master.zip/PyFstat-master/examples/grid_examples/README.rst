Grid searches for isolated CW
=============================

Fully-coherent F-statistic grid search for isolated
CW sources. The examples consist of directed searches
(i.e. fixed sky poistions) considering an isolated CW
source with 0, 1, and 2 spindown parameters.
