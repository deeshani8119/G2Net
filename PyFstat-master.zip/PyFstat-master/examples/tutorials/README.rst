Tutorials
=========

Notebook tutorials on how to use PyFstat both as a tool in itself and
as batteries-included Python wrapper to LALSuite.

Requires `PyFstat` 1.14.1 or later.
